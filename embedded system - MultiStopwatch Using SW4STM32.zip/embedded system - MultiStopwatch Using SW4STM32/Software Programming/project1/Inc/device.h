/*
 * device.h
 *
 *  Created on: Sep 27, 2017
 *      Author: hendri
 */

#ifndef DEVICE_H_
#define DEVICE_H_
//  start device.h
#define pb_ok GPIO_PIN_10
#define pb_cancel GPIO_PIN_11
#define pb_sensor1 GPIO_PIN_12
#define pb_sensor2 GPIO_PIN_13
#define pb_sensor3 GPIO_PIN_14
#define PB_GPIO_Port GPIOE

#endif /* DEVICE_H_ */
